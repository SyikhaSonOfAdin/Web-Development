# Qibla Finder
## An interactive qibla finder using Google Maps

Not that there was much of a real need for this as there are several such
websites out there as is, but I wanted to try my hand at this personally.
Just clone the repository and open up qibla.html locally. (Alternatively,
essentially the same code can be run here:
https://jsfiddle.net/readyready15728/em43hu2r/) The qibla calculation details
come from the paper *The Correct Qibla* by S. Kamal Abdali, which can be found
here:

http://nurlu.narod.ru/qibla.pdf
