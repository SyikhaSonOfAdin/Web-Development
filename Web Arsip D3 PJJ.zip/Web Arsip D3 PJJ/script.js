const insideCard = document.querySelector('.plus input') ;
const work = document.querySelector('.card-1 div') ;

insideCard.addEventListener('click', function() {
    work.classList.toggle('wdw') ;
})
const insideCard2 = document.querySelector('.plus-1 input') ;
const work2 = document.querySelector('.card-2 div') ;

insideCard2.addEventListener('click', function() {
    work2.classList.toggle('knt') ;
})
const insideCard3 = document.querySelector('.plus-2 input') ;
const work3 = document.querySelector('.card-3 div') ;

insideCard3.addEventListener('click', function() {
    work3.classList.toggle('logika') ;
})

const insideCard4 = document.querySelector('.plus-3 input') ;
const work4 = document.querySelector('.card-4 div') ;

insideCard4.addEventListener('click', function() {
    work4.classList.toggle('konsep') ;
})

const insideCard5 = document.querySelector('.plus-4 input') ;
const work5 = document.querySelector('.card-5 div') ;

insideCard5.addEventListener('click', function() {
    work5.classList.toggle('dsi') ;
})

const insideCard6 = document.querySelector('.plus-5 input') ;
const work6 = document.querySelector('.card-6 div') ;

insideCard6.addEventListener('click', function() {
    work6.classList.toggle('inggris') ;
})

const insideCard7 = document.querySelector('.plus-6 input') ;
const work7 = document.querySelector('.card-7 div') ;

insideCard7.addEventListener('click', function() {
    work7.classList.toggle('pancasila') ;
})

const insideCard8 = document.querySelector('.plus-7 input') ;
const work8 = document.querySelector('.card-8 div') ;

insideCard8.addEventListener('click', function() {
    work8.classList.toggle('math') ;
})

const insideCard9 = document.querySelector('.plus-8 input') ;
const work9 = document.querySelector('.card-9 div') ;

insideCard9.addEventListener('click', function() {
    work9.classList.toggle('kti') ;
})

const headerMenu = document.querySelector('.burger-nav input') ;
const workHeader = document.querySelector('.blue-header ul') ;

headerMenu.addEventListener('click', function() {
    workHeader.classList.toggle('menu') ;
})